const $=id=>document.getElementById(id);
let lastCheckout=null;
$("depositBtn").addEventListener("click",async()=>{
 const phone=$("phone").value.trim(), amount=Number($("amount").value);
 const msg=$("paymentMessage"); msg.textContent="Sending request…";
 try{
  const r=await fetch("/api/mpesa-stk",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({phone,amount})});
  const data=await r.json(); if(!r.ok) throw new Error(data.error||"Could not start payment");
  lastCheckout=data.CheckoutRequestID||null;
  msg.textContent=data.CustomerMessage||"STK Push request accepted. Check your phone and enter your M-Pesa PIN. This is not payment confirmation.";
  $("activity").textContent="Payment request submitted · "+(lastCheckout||"Awaiting callback");
 }catch(e){msg.textContent=e.message}
});
$("refresh").addEventListener("click",async()=>{
 if(!lastCheckout){$("activity").textContent="No payment request to check yet.";return}
 try{const r=await fetch("/api/mpesa-status?id="+encodeURIComponent(lastCheckout));const d=await r.json();$("activity").textContent=d.status||d.error||"Status pending"}
 catch(e){$("activity").textContent="Unable to retrieve status"}
});
