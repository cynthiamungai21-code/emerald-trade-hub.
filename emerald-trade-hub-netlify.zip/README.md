# Emerald Trade Hub — Netlify starter

This package is a Netlify-ready emerald/black dashboard with a Daraja STK Push starter integration.

## Deploy (no coding required)
1. Create a Netlify account and choose **Add new site → Deploy manually**.
2. Unzip this package on your computer. Drag the `emerald-trade-hub-netlify` folder contents into Netlify's deploy area, or connect the folder through Git.
3. For Netlify Functions and Blobs, use a Git-connected deploy or Netlify CLI. In a terminal run `npm install`, then `npx netlify deploy --build`; for production use `npx netlify deploy --build --prod`.
4. In Netlify: **Site configuration → Environment variables**, add the variable names listed below. Redeploy after changing variables.
5. In Safaricom Daraja, register the callback URL shown below after the site has a stable HTTPS domain.

## Netlify environment variables
- `DARAJA_CONSUMER_KEY` — Daraja Consumer Key (server secret)
- `DARAJA_CONSUMER_SECRET` — Daraja Consumer Secret (server secret)
- `DARAJA_PASSKEY` — STK Push Passkey (server secret)
- `DARAJA_SHORTCODE` — business shortcode
- `DARAJA_BASE_URL` — sandbox: `https://sandbox.safaricom.co.ke` (use production only after approval)
- `DARAJA_CALLBACK_URL` — `https://YOUR-SITE.netlify.app/api/mpesa-callback`
- `DERIV_APP_ID` — Deriv OAuth application ID
- `DERIV_REDIRECT_URI` — exact HTTPS callback URI registered with Deriv
- `PUBLIC_SITE_URL` — your deployed HTTPS site URL

## Important security and readiness notes
- Never place Consumer Secret, Passkey, or OAuth tokens in browser code or chat. The credentials previously pasted into chat should be rotated before use.
- This is a sandbox-first starter, not a live-money-ready wallet. The callback stores the provider callback, but production wallet crediting requires signature/source validation, a durable user ledger, reconciliation, authentication/authorization, fraud controls, and administrator review.
- The withdrawal control is intentionally disabled; Safaricom B2C payout integration and approvals are not implemented.
- Deriv link starts an OAuth authorization redirect only. Secure PKCE state/verifier storage, callback code exchange, token storage, live tick stream, and trade execution still need implementation before enabling trading. Trading buttons are intentionally disabled.
- Do not switch to live Daraja or accept real deposits until the full callback, ledger, reconciliation and security review has been completed.
- The app does not fake successful payments or trades.
