import { getStore } from "@netlify/blobs";
const json=(s,b)=>new Response(JSON.stringify(b),{status:s,headers:{"content-type":"application/json"}});
export default async(req)=>{
 if(req.method!=="POST")return json(405,{ResultCode:1,ResultDesc:"Method not allowed"});
 try{
  const payload=await req.json(), cb=payload?.Body?.stkCallback;
  if(!cb?.CheckoutRequestID||!cb?.MerchantRequestID)return json(400,{ResultCode:1,ResultDesc:"Invalid callback"});
  const store=getStore("mpesa-transactions");
  const key=cb.CheckoutRequestID;
  const existing=await store.get(key,{type:"json"});
  if(existing?.callbackReceived)return json(200,{ResultCode:0,ResultDesc:"Callback already processed"});
  const record={checkoutRequestId:key,merchantRequestId:cb.MerchantRequestID,resultCode:cb.ResultCode,resultDescription:cb.ResultDesc,callbackReceived:true,receivedAt:new Date().toISOString(),metadata:cb.CallbackMetadata?.Item||[]};
  await store.setJSON(key,record);
  return json(200,{ResultCode:0,ResultDesc:"Accepted"});
 }catch(e){return json(500,{ResultCode:1,ResultDesc:"Callback processing failed"})}
};
