import { randomUUID } from "node:crypto";
const json=(status,body)=>new Response(JSON.stringify(body),{status,headers:{"content-type":"application/json","cache-control":"no-store"}});
const env=k=>Netlify.env.get(k);
async function token(){
 const key=env("DARAJA_CONSUMER_KEY"),secret=env("DARAJA_CONSUMER_SECRET");
 if(!key||!secret) throw new Error("Daraja credentials are not configured in Netlify.");
 const base=env("DARAJA_BASE_URL")||"https://sandbox.safaricom.co.ke";
 const auth=Buffer.from(`${key}:${secret}`).toString("base64");
 const r=await fetch(`${base}/oauth/v1/generate?grant_type=client_credentials`,{headers:{Authorization:`Basic ${auth}`}});
 const d=await r.json();if(!r.ok||!d.access_token)throw new Error(d.errorMessage||"Daraja authentication failed");
 return d.access_token;
}
export default async(req)=>{
 if(req.method!=="POST")return json(405,{error:"Method not allowed"});
 try{
  const body=await req.json(), phone=String(body.phone||"").replace(/\D/g,""), amount=Number(body.amount);
  if(!/^2547\d{8}$/.test(phone))return json(400,{error:"Enter a valid Kenyan phone number in 2547XXXXXXXX format."});
  if(!Number.isInteger(amount)||amount<1||amount>250000)return json(400,{error:"Enter an amount between KES 1 and 250,000."});
  const shortcode=env("DARAJA_SHORTCODE"),passkey=env("DARAJA_PASSKEY"),callback=env("DARAJA_CALLBACK_URL");
  if(!shortcode||!passkey||!callback)return json(503,{error:"Daraja setup incomplete. Add shortcode, passkey and public HTTPS callback URL in Netlify environment variables."});
  const access=await token(),base=env("DARAJA_BASE_URL")||"https://sandbox.safaricom.co.ke";
  const timestamp=new Date().toISOString().replace(/[-:TZ.]/g,"").slice(0,14);
  const password=Buffer.from(`${shortcode}${passkey}${timestamp}`).toString("base64");
  const r=await fetch(`${base}/mpesa/stkpush/v1/processrequest`,{method:"POST",headers:{Authorization:`Bearer ${access}`,"Content-Type":"application/json"},body:JSON.stringify({
   BusinessShortCode:shortcode,Password:password,Timestamp:timestamp,TransactionType:"CustomerPayBillOnline",Amount:amount,
   PartyA:phone,PartyB:shortcode,PhoneNumber:phone,CallBackURL:callback,AccountReference:"EmeraldHub",TransactionDesc:"Wallet deposit"
  })});
  const d=await r.json();if(!r.ok||d.ResponseCode!=="0")return json(502,{error:d.errorMessage||d.ResponseDescription||"STK Push request failed"});
  return json(200,{...d,requestReference:randomUUID(),message:"STK Push sent. Funds are not credited until the verified callback is received."});
 }catch(e){return json(500,{error:e.message||"Payment service error"})}
};
