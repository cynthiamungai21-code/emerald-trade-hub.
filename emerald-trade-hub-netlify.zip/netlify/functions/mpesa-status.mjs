import { getStore } from "@netlify/blobs";
const json=(s,b)=>new Response(JSON.stringify(b),{status:s,headers:{"content-type":"application/json","cache-control":"no-store"}});
export default async(req)=>{
 const id=new URL(req.url).searchParams.get("id");
 if(!id)return json(400,{error:"Missing checkout request ID"});
 const store=getStore("mpesa-transactions"),record=await store.get(id,{type:"json"});
 if(!record)return json(200,{status:"Pending callback; not yet confirmed"});
 return json(200,{status:record.resultCode===0?"Payment callback received; reconcile before crediting wallet":"Payment not successful",resultCode:record.resultCode,receivedAt:record.receivedAt});
};
