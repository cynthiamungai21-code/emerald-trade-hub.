const json=(s,b)=>new Response(JSON.stringify(b),{status:s,headers:{"content-type":"application/json","cache-control":"no-store"}});
export default async(req)=>{
 const client=Netlify.env.get("DERIV_APP_ID"),redirect=Netlify.env.get("DERIV_REDIRECT_URI");
 if(!client||!redirect)return json(503,{error:"Deriv OAuth is not configured. Add DERIV_APP_ID and DERIV_REDIRECT_URI in Netlify environment variables."});
 return Response.redirect("https://auth.deriv.com/oauth2/auth?"+new URLSearchParams({client_id:client,response_type:"code",redirect_uri:redirect,scope:"read",state:crypto.randomUUID()}),302);
};
